# Projeto Casamento Simbólico

Instruções para rodar local e fazer deploy no Vercel + MongoDB Atlas